rpm -Uvh --force --nodeps *.rpm
