#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

MODULE_INFO(intree, "Y");

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xfe73e971, "module_layout" },
	{ 0xfce8fa9, "param_ops_byte" },
	{ 0xbb0d7032, "param_ops_bool" },
	{ 0x14a0381d, "param_ops_charp" },
	{ 0x69534b4c, "param_array_ops" },
	{ 0xa7d5f92e, "ida_destroy" },
	{ 0xa4f287cf, "hid_unregister_driver" },
	{ 0x8c03d20c, "destroy_workqueue" },
	{ 0x17ed90c0, "__hid_register_driver" },
	{ 0xdf9208c0, "alloc_workqueue" },
	{ 0x5495392, "hid_debug" },
	{ 0x81c76cd, "input_event" },
	{ 0x6cac0bf7, "power_supply_changed" },
	{ 0x449ad0a7, "memcmp" },
	{ 0x2198034, "hid_hw_start" },
	{ 0x10ecacde, "hid_open_report" },
	{ 0xe7a02573, "ida_alloc_range" },
	{ 0xa2d395f6, "input_ff_create_memless" },
	{ 0xd4fadbf1, "input_set_capability" },
	{ 0x38de23c2, "devm_kmalloc" },
	{ 0xc6f46339, "init_timer_key" },
	{ 0xffeedf6a, "delayed_work_timer_fn" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x2ea2c95c, "__x86_indirect_thunk_rax" },
	{ 0xc5850110, "printk" },
	{ 0x1d24c881, "___ratelimit" },
	{ 0xe70fe7b2, "power_supply_powers" },
	{ 0xaee44f7f, "devm_power_supply_register" },
	{ 0xb4181dd5, "hid_hw_stop" },
	{ 0xffb7c514, "ida_free" },
	{ 0x9fa7184a, "cancel_delayed_work_sync" },
	{ 0x333b3fa4, "hid_hw_close" },
	{ 0xd35cce70, "_raw_spin_unlock_irqrestore" },
	{ 0xb2fcb56d, "queue_delayed_work_on" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x34db050b, "_raw_spin_lock_irqsave" },
	{ 0xc2089bd8, "_dev_err" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0x37a0cba, "kfree" },
	{ 0x3b6c41ea, "kstrtouint" },
	{ 0x6fb9f1b5, "kernel_param_unlock" },
	{ 0xa916b694, "strnlen" },
	{ 0xfd6a31d0, "kernel_param_lock" },
	{ 0x5a921311, "strncmp" },
	{ 0x96b29254, "strncasecmp" },
	{ 0xfb384d37, "kasprintf" },
	{ 0x11410f65, "power_supply_get_drvdata" },
	{ 0x4517c36e, "_dev_notice" },
	{ 0x5569c9e5, "_dev_warn" },
	{ 0x8a395d7b, "input_set_abs_params" },
	{ 0x9ad53623, "_dev_info" },
	{ 0xc959d152, "__stack_chk_fail" },
	{ 0xbdfb6dbb, "__fentry__" },
};

MODULE_INFO(depends, "ff-memless");

MODULE_ALIAS("hid:b0005g*v0000045Ep000002FD");
MODULE_ALIAS("hid:b0005g*v0000045Ep000002E0");
MODULE_ALIAS("hid:b0005g*v0000045Ep00000B05");
MODULE_ALIAS("hid:b0005g*v0000045Ep00000B13");

MODULE_INFO(srcversion, "5467921CFCB1964F59E30F8");
