#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xc3598a87, "module_layout" },
	{ 0xb44ad4b3, "_copy_to_user" },
	{ 0xf568ba13, "usb_register_driver" },
	{ 0xbaad5895, "__napi_schedule" },
	{ 0x85df9b6c, "strsep" },
	{ 0x304a6cd5, "eth_type_trans" },
	{ 0x21303128, "napi_gro_receive" },
	{ 0x719e781c, "single_release" },
	{ 0xdb7305a1, "__stack_chk_fail" },
	{ 0xd2da1048, "register_netdevice_notifier" },
	{ 0x88fe151f, "skb_queue_tail" },
	{ 0xeae3dfd6, "__const_udelay" },
	{ 0x20000329, "simple_strtoul" },
	{ 0xaff90c87, "cfg80211_mgmt_tx_status" },
	{ 0x69acdf38, "memcpy" },
	{ 0xe3ce3ea4, "proc_mkdir_data" },
	{ 0x3f0ccf54, "dev_get_by_name" },
	{ 0x1ed8b599, "__x86_indirect_thunk_r8" },
	{ 0x91715312, "sprintf" },
	{ 0x9c64fbd, "ieee80211_frequency_to_channel" },
	{ 0xf66868e6, "cfg80211_rx_mgmt" },
	{ 0x654e2409, "napi_disable" },
	{ 0xa027787, "free_netdev" },
	{ 0x768459c9, "__cfg80211_alloc_reply_skb" },
	{ 0xf6fe9427, "unregister_netdevice_queue" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x5a1c39b9, "__pskb_copy_fclone" },
	{ 0xd9a5ea54, "__init_waitqueue_head" },
	{ 0xa4b1d364, "usb_submit_urb" },
	{ 0x301fa007, "_raw_spin_unlock" },
	{ 0xd20a8f0, "netif_receive_skb" },
	{ 0x760a0f4f, "yield" },
	{ 0xc4f0da12, "ktime_get_with_offset" },
	{ 0xa6093a32, "mutex_unlock" },
	{ 0x60352082, "register_inet6addr_notifier" },
	{ 0x85e3c45a, "alloc_etherdev_mqs" },
	{ 0xc6c73f3a, "usb_free_urb" },
	{ 0xd6516842, "cfg80211_new_sta" },
	{ 0x8d522714, "__rcu_read_lock" },
	{ 0xf989c116, "unregister_netdev" },
	{ 0xf9a482f9, "msleep" },
	{ 0xf6afb046, "flush_signals" },
	{ 0x9d0d6206, "unregister_netdevice_notifier" },
	{ 0x799c3bc8, "cfg80211_inform_bss_frame_data" },
	{ 0x2469810f, "__rcu_read_unlock" },
	{ 0xe3fffae9, "__x86_indirect_thunk_rbp" },
	{ 0x3c7c9a5, "ieee80211_get_channel" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0x6de13801, "wait_for_completion" },
	{ 0x5ed935a4, "dev_alloc_name" },
	{ 0x1fdf4298, "usb_kill_urb" },
	{ 0x51760917, "_raw_spin_lock_irqsave" },
	{ 0xbb4dfd8d, "netif_carrier_on" },
	{ 0x50afab93, "cfg80211_unlink_bss" },
	{ 0x404e1c20, "__dev_kfree_skb_any" },
	{ 0x99782cef, "proc_create_data" },
	{ 0x19a3ee09, "find_vpid" },
	{ 0xf06355d8, "usb_alloc_coherent" },
	{ 0xefbe94b2, "skb_realloc_headroom" },
	{ 0x1000e51, "schedule" },
	{ 0x16a1b499, "skb_push" },
	{ 0x4d1ff60a, "wait_for_completion_timeout" },
	{ 0x6df1aaf1, "kernel_sigaction" },
	{ 0xea983806, "kill_pid" },
	{ 0xb94623b1, "skb_trim" },
	{ 0x90a4e868, "cfg80211_connect_done" },
	{ 0x97934ecf, "del_timer_sync" },
	{ 0x663e8ef9, "current_task" },
	{ 0xb3635b01, "_raw_spin_lock_bh" },
	{ 0x3fb5d488, "netif_napi_add" },
	{ 0xcf2a6966, "up" },
	{ 0xfe029963, "unregister_inetaddr_notifier" },
	{ 0x2ea2c95c, "__x86_indirect_thunk_rax" },
	{ 0xceec6099, "register_netdev" },
	{ 0xa2ef0575, "cfg80211_put_bss" },
	{ 0x1ff81e52, "cfg80211_roamed" },
	{ 0xf68285c0, "register_inetaddr_notifier" },
	{ 0xd70b4186, "remove_proc_entry" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x263ed23b, "__x86_indirect_thunk_r12" },
	{ 0xe5fe4164, "cfg80211_scan_done" },
	{ 0xb3f7646e, "kthread_should_stop" },
	{ 0x9a76f11f, "__mutex_init" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0xb8d55334, "napi_complete_done" },
	{ 0x83f50931, "seq_read" },
	{ 0x4a928de6, "mutex_lock_interruptible" },
	{ 0xdf2f9832, "netif_carrier_off" },
	{ 0x66decfd5, "ns_to_timespec" },
	{ 0x2100095b, "usb_get_dev" },
	{ 0x557d3a1d, "param_ops_uint" },
	{ 0xf05c7b8, "__x86_indirect_thunk_r15" },
	{ 0x774df52b, "kthread_create_on_node" },
	{ 0xa87c0aa8, "wake_up_process" },
	{ 0xc18a4d01, "register_netdevice" },
	{ 0x2ca64785, "seq_lseek" },
	{ 0x51189001, "PDE_DATA" },
	{ 0xbbc58365, "skb_copy" },
	{ 0x4629334c, "__preempt_count" },
	{ 0x84852720, "param_ops_charp" },
	{ 0xc38c83b8, "mod_timer" },
	{ 0x96524d80, "skb_copy_bits" },
	{ 0x9166fada, "strncpy" },
	{ 0x7b21bf4c, "cfg80211_ibss_joined" },
	{ 0x31643fa4, "netif_rx" },
	{ 0x82072614, "tasklet_kill" },
	{ 0xc3e28a81, "usb_deregister" },
	{ 0x6c5511ac, "skb_dequeue" },
	{ 0x21abc96a, "cfg80211_michael_mic_failure" },
	{ 0xc25f7b8b, "netif_tx_wake_queue" },
	{ 0x8133c67d, "complete_and_exit" },
	{ 0x48cab03f, "cfg80211_disconnected" },
	{ 0xb47cca30, "csum_ipv6_magic" },
	{ 0x4b6b8ef5, "kthread_stop" },
	{ 0xfda9581f, "prandom_u32" },
	{ 0x38722f80, "kernel_fpu_end" },
	{ 0x47939e0d, "__tasklet_hi_schedule" },
	{ 0x9a1dfd65, "strpbrk" },
	{ 0xfffe3f55, "init_net" },
	{ 0x426f75f, "__cfg80211_send_event_skb" },
	{ 0x96b29254, "strncasecmp" },
	{ 0x349cba85, "strchr" },
	{ 0x37a0cba, "kfree" },
	{ 0x6aa6de6c, "seq_printf" },
	{ 0x29361773, "complete" },
	{ 0xda3dd073, "cfg80211_get_bss" },
	{ 0xf7756eb5, "wiphy_new_nm" },
	{ 0xf9765471, "param_array_ops" },
	{ 0xe99e1790, "wiphy_free" },
	{ 0x2e0d2f7f, "queue_work_on" },
	{ 0x4569f990, "device_init_wakeup" },
	{ 0xb601be4c, "__x86_indirect_thunk_rdx" },
	{ 0x49c41a57, "_raw_spin_unlock_bh" },
	{ 0xac7ed948, "seq_open" },
	{ 0x362ef408, "_copy_from_user" },
	{ 0x25170ad2, "down_interruptible" },
	{ 0xf6f7be7d, "proc_get_parent_data" },
	{ 0xa416f639, "kernel_read" },
	{ 0x4b06cf29, "skb_put" },
	{ 0xe113bbbc, "csum_partial" },
	{ 0x19004756, "cfg80211_ready_on_channel" },
	{ 0x12a38747, "usleep_range" },
	{ 0xe914e41e, "strcpy" },
	{ 0xd986dad1, "kernel_fpu_begin" },
	{ 0x7f02188f, "__msecs_to_jiffies" },
	{ 0x99da4f24, "skb_clone" },
	{ 0x5a921311, "strncmp" },
	{ 0x96010a8f, "usb_put_dev" },
	{ 0x4ea34002, "filp_close" },
	{ 0x3812050a, "_raw_spin_unlock_irqrestore" },
	{ 0xb0e602eb, "memmove" },
	{ 0x71ba5fd0, "cfg80211_ch_switch_notify" },
	{ 0x8a80053f, "usb_control_msg" },
	{ 0xb4ddd325, "param_ops_int" },
	{ 0xb4a6ffef, "napi_schedule_prep" },
	{ 0xc6f46339, "init_timer_key" },
	{ 0xd2b09ce5, "__kmalloc" },
	{ 0xfb937ef2, "single_open" },
	{ 0xfb578fc5, "memset" },
	{ 0xc775c134, "__pskb_pull_tail" },
	{ 0xdbf17652, "_raw_spin_lock" },
	{ 0x11e94b21, "usb_alloc_urb" },
	{ 0x9e7d6bd0, "__udelay" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x8a628661, "usb_reset_device" },
	{ 0x37befc70, "jiffies_to_msecs" },
	{ 0x77503d41, "filp_open" },
	{ 0xc4fb8aa3, "usb_autopm_get_interface" },
	{ 0x28318305, "snprintf" },
	{ 0x82dcd9c8, "wiphy_unregister" },
	{ 0x21b21e20, "seq_release" },
	{ 0x2387d05b, "netif_tx_stop_all_queues" },
	{ 0x55800710, "cfg80211_del_sta_sinfo" },
	{ 0x9545af6d, "tasklet_init" },
	{ 0x17770ba1, "cfg80211_vendor_cmd_reply" },
	{ 0xfaef0ed, "__tasklet_schedule" },
	{ 0x20c55ae0, "sscanf" },
	{ 0xc29957c3, "__x86_indirect_thunk_rcx" },
	{ 0xb5431793, "__netdev_alloc_skb" },
	{ 0x27e1a049, "printk" },
	{ 0x5dcb891a, "nla_put_nohdr" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0x2ae60bb3, "cfg80211_remain_on_channel_expired" },
	{ 0xe8663ae6, "ieee80211_channel_to_frequency" },
	{ 0x1ec23d6f, "nla_put" },
	{ 0x6e347441, "wiphy_register" },
	{ 0x29534540, "__cfg80211_alloc_event_skb" },
	{ 0x999e8297, "vfree" },
	{ 0xeaf651e9, "netif_napi_del" },
	{ 0x449ad0a7, "memcmp" },
	{ 0x2fe252cc, "unregister_inet6addr_notifier" },
	{ 0x88bfa7e, "cancel_work_sync" },
	{ 0xa140d8ae, "usb_free_coherent" },
	{ 0x85670f1d, "rtnl_is_locked" },
	{ 0x4a93d4f6, "skb_pull" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("usb:v0BDAp8812d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDAp881Ad*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDAp881Bd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDAp881Cd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v050Dp1106d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v7392pA822d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0DF6p0074d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v04BBp0952d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0789p016Ed*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0409p0408d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0B05p17D2d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0E66p0022d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0586p3426d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2001p3313d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1058p0632d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v1740p0100d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2019pAB30d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v07B8p8812d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0846p9051d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2001p330Ed*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2001p3313d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2001p3315d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2001p3316d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v13B1p003Fd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2357p0101d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2357p0103d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2357p010Dd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2357p010Ed*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2357p010Fd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2357p0122d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v20F4p805Bd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0411p025Dd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v050Dp1109d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v148Fp9097d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDAp8812d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2604p0012d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDAp881Ad*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDAp0811d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDAp0821d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDAp8822d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDApA811d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDAp0820d*dc*dsc*dp*icFFiscFFipFFin*");
MODULE_ALIAS("usb:v0BDAp0823d*dc*dsc*dp*icFFiscFFipFFin*");
MODULE_ALIAS("usb:v7392pA811d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v7392pA812d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v7392pA813d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v04BBp0953d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2001p3314d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2001p3318d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0E66p0023d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v056Ep400Ed*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v056Ep400Fd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0411p0242d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2019pAB32d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0846p9052d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0411p029Bd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v056Ep4007d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDApA811d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDAp8813d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2001p331Ad*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0B05p1817d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0B05p1852d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0B05p1853d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v056Ep400Bd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v056Ep400Dd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v7392pA834d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v7392pA833d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0BDAp8813d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v2357p0106d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v20F4p809Ad*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v20F4p809Bd*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v0846p9054d*dc*dsc*dp*ic*isc*ip*in*");

MODULE_INFO(srcversion, "2D12B520625A61D341088F0");
