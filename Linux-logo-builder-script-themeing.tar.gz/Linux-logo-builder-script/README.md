# Linux-logo-builder-script
a script to reformat a .ppm image and place it into the linux source directory for changing the boot logo,


# *** <br> Please don't do malovent things with this script its intended just for </br>
# *** <br> simple artistic construction when </br>
# *** <br> booting your OS, </br>
# *** <br> there are enough dirty things floating around the internet, </br>

I claim no responsibility for the use of the script,

# included please see a sample for a 224 color palette format with netpbm





# *** script built from http://www.armadeus.org/wiki/index.php?title=Linux_Boot_Logo
