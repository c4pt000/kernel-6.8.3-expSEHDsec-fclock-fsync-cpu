#!/bin/bash





#ppmquant 224 logo-build.ppm > my_boot_logo_224.ppm
#pnmnoraw my_boot_logo_224.ppm > my_boot_logo_ascii_224.ppm


ppmquant 224 'moon.ppm' > my_boot_logo_224.ppm
pnmnoraw my_boot_logo_224.ppm > my_boot_logo_ascii_224.ppm

cp -v my_boot_logo_ascii_224.ppm logo-moon.ppm

echo "logo-moon.ppm"

#cp -v logo-current.ppm 
#/opt/linux-4.4.167/drivers/video/logo/logo_linux_clut224.ppm
#penguin-logo-74x109px.ppm
